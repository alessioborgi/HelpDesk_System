INSERT INTO public."TECHNOLOGY_COMPANY"
("ID_Fleet_Company" ,"Fleet_Bank_Account","Address_Fleet_Company","Telephone_Fleet_Company","Name_Fleet_Company")    
VALUES
(('IDBFC',1927975790),  'IT71J0300203280863545639516', 'Via Giulio Vincenzo Bona 110', 0641595678,'Mercedes-Benz' );