INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBFD',842036519744356), 2022-07-15, 5, '2022-06-01 12:23:54');



INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBFD',22598756300025), 2022-06-15, 5, '2022-05-27 21:00:00');



INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBFD',04587210511234), 2022-05-15, 5, '2022-05-12 11:45:52');



INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBFD',00257489610000), 2022-07-15, 10, '2022-01-09 09:20:58');




INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBFD',157896452343526), 2022-06-15, 10, '2022-04-30 21:45:20');




INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBFD',448562789511234), 2022-05-15, 10, NULL);




INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBFD',4685627519745871), 2022-07-15, 15, '2022-06-16 20:56:54');




INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBFD',788514587109098), 2022-06-15, 15, '2022-06-09 12:55:08');



INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBFD',551278964511123), 2022-05-15, 15, '2022-04-17 14:27:19');




INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBFD',447152036987635), 2022-07-15, 20, NULL);



INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBFD',200154869763021), 2022-06-15, 20, '2022-06-11 12:38:00');



INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBBK',111784520011579), 2022-05-15, 20, NULL);



INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBBK',5558463251001935), 2022-07-15, 25, '2022-05-13 07:28:39');



INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBBK',589745126377765), 2022-06-15, 25, NULL);


INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBBK',445872631010098), 2022-05-15, 25, '2022-04-18 21:12:07');


INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBBK',445872631010098), 2022-07-15, 25, '2022-06-18 11:12:50');


INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBBK',445872631010098), 2022-06-15, 25, '2022-05-28 21:12:07');




INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBBK',445872631010098), 2022-05-15, 25, '2022-05-11 06:12:57');



INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBBK',445872631010098), 2022-07-15, 30, '2022-06-08 23:00:00');




INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBBK',445872631010098), 2022-06-15 30, '2022-05-15 13:38:05');




INSERT INTO public."FOOD_STAMP"
("ID_Benefit_Food_Stamp","Expiry_Date_Food_Stamp","Value_Food_Stamp","Date_Time_Usage")  
VALUES
(('IDBBK',445872631010098), 2022-05-15, 30, '2022-04-30 08:01:20');