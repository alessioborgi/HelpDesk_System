INSERT INTO public."TICKET"
("ID_Ticket", "Closed_Ticket", "Product_Typology", "Priority_Ticket", "Company_Failure", "Problem_Description", "Name_Applicant", "Date_Time_Submission", "Date_Time_Closure", "ID_Customer", "ID_Product")
VALUES
(('IDTCK',1234568907), true, 'Electronic Products', 3, 'apple', 'SIM', 'Luca', now(), now(), ('IDCU', 5874122369), ('IDPRD',1234568907));