INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9765359800),40, 'L','L',() );


INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',5789462101),37, 'S','M',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9986541202),43, 'M','S',() );


INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9963352403),42, 'L','M',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',7784563204),36, 'S','S',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',6874152305),38, 'S','XS',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',8854263106),39, 'M','M',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',1188975607),40, 'L','XL',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9987456308),46, 'XL','XXL',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',0004589609),42, 'L','M',() );




INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',1562456210),45, 'XL','XXL',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9998746311),37, 'S','XXS',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9876522012),38, 'M','M',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',5554869513),39, 'S','M',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9775634814),43, 'M','L',() );


INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9987456315),44, 'L','XXL',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9876453216),40, 'M','S',() );


INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9876543217),39, 'M','M',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',98745635118),41, 'L','L',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9875635119),45, 'XL','XXL',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',4896756220),36, 'XS','XS',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',4111098721),40, 'L','M',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9990768522),45, 'XL','XXL',() );




INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',4487965223),43, 'L','L',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',1111899624),39, 'L','S',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',7777889925),35, 'S','XS',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',5454663326),38, 'S','M',() );


INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',8787888827),39, 'M','S',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',5556463828),37, 'M','M',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',4446665529),46, 'XL','XXL',() );

---

INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',48975698530)44, 'L','XL',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',8885642331),44, 'L','M',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',6793289732),37, 'L','L',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',0912631033),36, 'XS','XS',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',5428901434),43, 'L','L',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',3334879535),41, 'M','L',() );


INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9998775636),39, 'M','M',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',0002987637),41, 'L','S',() );




INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9997846538),41, 'M','S',() );




INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',4848986539),43, 'XL','XL',() );




INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',5889874540),45, 'XXL','XL',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9696856241),39, 'M','L',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',6639874542),42, 'M','M',() );




INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9995554143),44, 'L','XL',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',0010105244),35, 'XS','XS',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',1119898645),37, 'M','S',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',4646963546),46, 'XXL','XXL',() );


INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',3338787947),45, 'XL','XXL',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',8282725648),39, 'L','XL',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9686351749),43, 'XL','L',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',4879562350),37, 'S','S',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',8874596551),44, 'XL','XL',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9686523252),42, 'L','L',() );


INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',7979854253),43, 'XL','L',() );




INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',6669898754)39, 'L','M',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',7353624555),45, 'M','M',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',7595863556),36, 'S','S',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',7985642657),44, 'XL','XXL',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9875632558),40, 'L','S',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',8596741259),39, 'M','L',() );




INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',2828978560),38, 'M','M',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9785646261),43, 'M','XL',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',0052486462),36, 'M','S',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',1489756263),38, 'M','L',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',7852466464),42, 'L','L',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9362451665),39, 'M','M',() );


INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',8202025166),40, 'L','XL',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',6854123067),35, 'XS','XS',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9105658968),37, 'M','S',() );



INSERT INTO public."2ND_LEVEL_TECHNICIAN"
( "ID_Tech_2","Shoes_Size","Helmet_Size","Clothing_Size", "ID_Account_Manager")
VALUES
(('IDWT2',9063521469),39, 'S','M',() );
