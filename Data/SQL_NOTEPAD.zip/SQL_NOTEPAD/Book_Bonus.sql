INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',842036519725846), 2023-08-17, 20, '2022-02-19 10:23:54');



INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',225987563210458), 2028-12-27, 20, '2019-11-08 22:00:00');



INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',44587210569836), 2022-07-19, 30, '2021-07-19 11:45:52');



INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',002574896130254), 2019-11-30, 30, '2022-01-09 09:20:58');




INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',157896452301528), 2021-06-19, 30, '2021-04-30 23:45:20');




INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',448562789512045), 2026-05-02, 20, NULL);




INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',4685627519745871), 2023-03-10, 20, '2022-01-16 21:56:54');




INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',788514587151975), 2024-01-01, 20, '2020-08-09 10:55:08');



INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',551278964523016), 2023-12-12, 30, '2021-06-17 14:27:19');




INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',447152036985412), 2021-09-11, 30, '2019-04-11 12:38:00');



INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',200154869763021), 2024-08-16, 50, NULL);



INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',111784520036541), 2025-02-06, 50, NULL);



INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',5558463251028475), 2022-10-09, 50, '2018-05-13 07:48:39');



INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',589745126302587), 2026-09-15, 50, NULL);


INSERT INTO public."BOOK_BONUS"
("ID_Benefit_Book_Bonus" ,"Expiry_Date_Book_Bonus","Value_Book_Bonus","Date_Time_Usage")  
VALUES
(('IDBBK',445872631025874), 2011-09-19, 50, '2011-09-18 21:12:07');