INSERT INTO public."MATERIAL"
("ID_Material","Name_Material")    
VALUES
(('IDMAT',11457),  'Fireproof Material');



INSERT INTO public."MATERIAL"
("ID_Material","Name_Material")    
VALUES
(('IDMAT',34562),  'Plastic');



INSERT INTO public."MATERIAL"
("ID_Material","Name_Material")    
VALUES
(('IDMAT',10098),  'Reflective Material');



INSERT INTO public."MATERIAL"
("ID_Material","Name_Material")    
VALUES
(('IDMAT',44678),  'Nylon');



INSERT INTO public."MATERIAL"
("ID_Material","Name_Material")    
VALUES
(('IDMAT',22510),  'Polyester');




INSERT INTO public."MATERIAL"
("ID_Material","Name_Material")    
VALUES
(('IDMAT',77621),  'Leather Material');




INSERT INTO public."MATERIAL"
("ID_Material","Name_Material")    
VALUES
(('IDMAT',00065),  'Book Shop');


