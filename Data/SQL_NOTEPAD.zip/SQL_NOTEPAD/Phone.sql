INSERT INTO public."PHONE_BENEFIT"
("ID_Benefit_Phone_Benefit","Assigned_Up_To_Phone","OS_Phone","Brand_Phone","Width_Phone","Height_Phone","Price_Phone","Inch_Screen_Phone","ID_Company_Tech", "Model_Phone_Benefit")  
VALUES
(('IDBPH',8429965197),  2024-12-31 , 'Android', 'Samsung', 72, 166, 1099,7,('IDTHC',5841236044), 'Galaxy Z Flip3 5G');



INSERT INTO public."PHONE_BENEFIT"
("ID_Benefit_Phone_Benefit","Assigned_Up_To_Phone","OS_Phone","Brand_Phone","Width_Phone","Height_Phone","Price_Phone","Inch_Screen_Phone","ID_Company_Tech", "Model_Phone_Benefit")  
VALUES
(('IDBPH',2259005632),  2025-12-31, 'Android', 'Samsung', 70, 146,879, 6,('IDTHC',5841236044),'Samsung S22');



INSERT INTO public."PHONE_BENEFIT"
("ID_Benefit_Phone_Benefit","Assigned_Up_To_Phone","OS_Phone","Brand_Phone","Width_Phone","Height_Phone","Price_Phone","Inch_Screen_Phone","ID_Company_Tech", "Model_Phone_Benefit")  
VALUES
(('IDBPH',2496621583),  2025-12-31, 'Android', 'Samsung', 74,159,469,6,('IDTHC',5841236044),'Galaxy A53 5G');




INSERT INTO public."PHONE_BENEFIT"
("ID_Benefit_Phone_Benefit","Assigned_Up_To_Phone","OS_Phone","Brand_Phone","Width_Phone","Height_Phone","Price_Phone","Inch_Screen_Phone","ID_Company_Tech", "Model_Phone_Benefit")  
VALUES
(('IDBPH',4496678210), 2025-12-31,'IoS','Apple', 71,146,1189,6,('IDTHC',6429735520),'iPhone Pro 13');




INSERT INTO public."PHONE_BENEFIT"
("ID_Benefit_Phone_Benefit","Assigned_Up_To_Phone","OS_Phone","Brand_Phone","Width_Phone","Height_Phone","Price_Phone","Inch_Screen_Phone","ID_Company_Tech", "Model_Phone_Benefit")  
VALUES
(('IDBPH',3365487210), 2025-12-31, 'IoS', 'Apple', 67,138,529,5,('IDTHC',6429735520),'iPhone SE');



INSERT INTO public."PHONE_BENEFIT"
("ID_Benefit_Phone_Benefit","Assigned_Up_To_Phone","OS_Phone","Brand_Phone","Width_Phone","Height_Phone","Price_Phone","Inch_Screen_Phone","ID_Company_Tech", "Model_Phone_Benefit")  
VALUES
(('IDBPH',5841236044), 2025-12-31, 'IoS', 'Apple', 64,131,839,5,('IDTHC',6429735520),'iPhone 13 mini');



INSERT INTO public."PHONE_BENEFIT"
("ID_Benefit_Phone_Benefit","Assigned_Up_To_Phone","OS_Phone","Brand_Phone","Width_Phone","Height_Phone","Price_Phone","Inch_Screen_Phone","ID_Company_Tech", "Model_Phone_Benefit")  
VALUES
(('IDBPH',7551036521),  2024-12-31, 'EMUI', 'Huawei', 75,170,1500,7,('IDTHC',4425502300),'Huawei P50 Pocket');




INSERT INTO public."PHONE_BENEFIT"
("ID_Benefit_Phone_Benefit","Assigned_Up_To_Phone","OS_Phone","Brand_Phone","Width_Phone","Height_Phone","Price_Phone","Inch_Screen_Phone","ID_Company_Tech", "Model_Phone_Benefit")  
VALUES
(('IDBPH',8420365197),  2023-12-31, 'EMUI', 'Huawei', 75,163,1249,7,('IDTHC',4425502300), 'Huawei Mate 40 PRO');





INSERT INTO public."PHONE_BENEFIT"
("ID_Benefit_Phone_Benefit","Assigned_Up_To_Phone","OS_Phone","Brand_Phone","Width_Phone","Height_Phone","Price_Phone","Inch_Screen_Phone","ID_Company_Tech", "Model_Phone_Benefit")  
VALUES
(('IDBPH',1578964523),  2023-12-31, 'EMUI', 'Huawei', 73,160,400,6,('IDTHC',4425502300), 'Huawei Nova 9');





INSERT INTO public."PHONE_BENEFIT"
("ID_Benefit_Phone_Benefit","Assigned_Up_To_Phone","OS_Phone","Brand_Phone","Width_Phone","Height_Phone","Price_Phone","Inch_Screen_Phone","ID_Company_Tech", "Model_Phone_Benefit")  
VALUES
(('IDBPH',1234573560),  2025-12-31, 'ColorOS', 'Oppo', 73,163,900,7,('IDTHC',7551036521),'Oppo Find X5 Pro');





INSERT INTO public."PHONE_BENEFIT"
("ID_Benefit_Phone_Benefit","Assigned_Up_To_Phone","OS_Phone","Brand_Phone","Width_Phone","Height_Phone","Price_Phone","Inch_Screen_Phone","ID_Company_Tech", "Model_Phone_Benefit")  
VALUES
(('IDBPH',3030332568),  2025-12-31, 'ColorOS', 'Oppo', 73,160,300,6,('IDTHC',7551036521),'Oppo Reno 7');



INSERT INTO public."PHONE_BENEFIT"
("ID_Benefit_Phone_Benefit","Assigned_Up_To_Phone","OS_Phone","Brand_Phone","Width_Phone","Height_Phone","Price_Phone","Inch_Screen_Phone","ID_Company_Tech", "Model_Phone_Benefit")  
VALUES
(('IDBPH',3368452210),  2025-12-31, 'ColorOS', 'Oppo', 75, 164, 270, 6,('IDTHC',7551036521),'Oppo A96');
