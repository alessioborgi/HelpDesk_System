INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',8429965197),  2024-12-31 , 'Windows', 'Samsung', 72, 166, 1449,'256 GB','8 GB',13,('IDTHC',5841236044), 'Galaxy Book2 Pro');



INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',2259005632),  2025-12-31 , 'Chrome OS', 'Samsung', 327, 255, 399,'256 GB','8 GB',14,('IDTHC',5841236044), 'Galaxy Chromebook Go');




INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',2496621583),  2022-12-31 , 'Windows', 'Samsung', 365, 229, 1109,'512 GB','4 GB',15,('IDTHC',5841236044), 'Galaxy Book');




INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',4496678210),  2024-12-31 , 'MacOS', 'Apple', 304, 161, 1159,'256 GB','8 GB',13,('IDTHC',6429735520), 'MacBook Air');




INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',3365487210),  2023-12-31 , 'MacOS', 'Apple', 304, 156, 1479,'256 GB','8 GB',13,('IDTHC',6429735520), 'MacBook Pro 13');




INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',5841236044),  2024-12-31 , 'MacOS', 'Apple', 547, 461, 1499,'2 Tr','16 GB',24,('IDTHC',6429735520), 'iMac 24');




INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',7551036521),  2024-12-31 , 'Windows', 'HP', 354, 242, 599,'256 GB','8 GB',15,('IDTHC',5521896351), 'HP 250 G8 Notebook PC');




INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',8420365197),  2024-12-31 , 'WIndows', 'HP', 338, 224, 649,'512 GB','8 GB',14,('IDTHC',5521896351), 'HP Pavilion 14');



INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',1578964523),  2024-12-31 , 'Chrome OS', 'HP', 414, 321, 699,'256 GB','4 GB',21,('IDTHC',5521896351), 'HP Chromebase 22-aa0003nl');



INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',1234573560),  2025-12-31 , 'Windows', 'Asus', 304, 203, 799,'512 GB','8 GB',13,('IDTHC',5597423015), 'Zenook 13 OLED');



INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',30303325687),  2024-12-31 , 'Windows', 'Asus', 304, 203, 1099,'512 GB','8 GB',7,('IDTHC',5597423015), 'Vivobook Pro 16X');




INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',3368452210),  2025-12-31 , 'Windows', 'Asus', 540, 409, 1099,'256 GB','4 GB',24,('IDTHC',5597423015), 'ASUS Vivo AIO 24 V241');




INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',8836278902),  2024-12-31 , 'Windows', 'Microsoft', 308, 223, 999,'1 Tr','8 GB',15,('IDTHC',5841236044), 'Surface Laptop 4');




INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',11928374650),  2024-12-31 , 'Windows', 'Microsoft', 278, 205, 279,'256 GB','8 GB',13,('IDTHC',5841236044), 'Surface Laptop Go');




INSERT INTO public."PC_BENEFIT"
("ID_Benefit_PC_Benefit","Assigned_Up_To_PC","OS_PC","Brand_PC","Width_PC","Height_PC","Price_PC","HD_Dimension_PC","RAM_Dimension_PC","Inch_Screen_PC","ID_Company_Tech", "Model_PC_Benefit")  
VALUES
(('IDBPC',9908007465),  2022-12-31 , 'Windows', 'Microsoft', 637, 438, 1499,'256 GB','8 GB',28,('IDTHC',5841236044), 'Surface Studio 2');

