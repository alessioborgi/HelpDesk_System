
-----CAR_LEADERSHIP

INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','GE648UH'),'Mercedes-Benz E-Class',2022-12-31, 55437,'Mercedes',612,6,5000,2021-12-31,40000,2022-07-31,'Platinum', ('IDBFC',1927975790));



INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','HF567YT'), 'Mercedes-Benz E-Class',2022-12-31, 55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-05-31,'Platinum',('IDBFC',1927975790));




INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','FL649IJ'),'Mercedes-Benz E-Class'  ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-12-31,40000,2022-07-31,'Platinum',('IDBFC',1927975790));



INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AD354KK'),'Mercedes-Benz E-Class'  ,2022-07-15,  55437,'Mercedes', 612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));




INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','KA546IU'),'Mercedes-Benz E-Class',2022-12-31,  55437,'Mercedes-Benz',612,6,5000,2022-12-31,40000,2022-07-31,'Platinum',('IDBFC',1927975790));




INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AL990CV'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));




----------CAR_FINANCE

INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','RE964FF'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));



INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','WK999LM'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));



INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','MV002GH'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));



INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','JW77HB'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));




INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','TY103GG'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));




INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','BB662LK'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));



INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','JI779SA'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));




INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AL990CV'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));




INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AL990CV'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));




INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AL990CV'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));




INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AL990CV'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));



INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AL990CV'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));




INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AL990CV'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));




INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AL990CV'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));




INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AL990CV'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));




INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AL990CV'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));




INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AL990CV'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));



INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AL990CV'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));



INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AL990CV'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));



INSERT INTO public."CAR_BENEFIT"
("ID_Car_Benefit","Model_Car","Assigned_Up_To_Car","Price_Car","Brand_Car","Horsepower_Car","Engine_Cylinder_Volume_Vehicle","Rent_Price_Car","Number_Seats_Car","Insurance_Validity_Up_To","Kilometers_Traveled","Rent_Expiry_Date","Car_Level_Price","ID_Fleet_Company")  
VALUES
(('IDBCR','AL990CV'),'Mercedes-Benz E-Class' ,2022-12-31,  55437,'Mercedes',612,6,5000,2022-07-31,40000,2022-12-31,'Platinum',('IDBFC',1927975790));





