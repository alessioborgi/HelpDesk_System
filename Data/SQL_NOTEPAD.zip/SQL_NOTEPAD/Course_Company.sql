INSERT INTO public."COURSE_COMPANY"
("ID_Course_Company","Address_Course_Company","Telephone_Course_Company","Email_Course_Company")    
VALUES
(('IDCCP',6429735520),  'Via Cola di Rienzo 140', 0694800751, ('corsi','@','britishcouncil','.','it'), 'British Council' );

 
INSERT INTO public."COURSE_COMPANY"
("ID_Course_Company","Address_Course_Company","Telephone_Course_Company","Email_Course_Company")    
VALUES
(('IDCCP',5841236044),  'Piazza degli Affari 6 ', 0272426086, ('academy','@','euronext','.','com'), 'Academy' );


INSERT INTO public."COURSE_COMPANY"
("ID_Course_Company","Address_Course_Company","Telephone_Course_Company","Email_Course_Company")    
VALUES
(('IDCCP',7551036521),  'Via Vittorio Emanuele 63', 0924076880,('info','@','corsisicurezza','.','it'), 'Corsi Sicurezza' ); 


INSERT INTO public."COURSE_COMPANY"
("ID_Course_Company","Address_Course_Company","Telephone_Course_Company","Email_Course_Company")    
VALUES
(('IDCCP',5597423015),  'Largo Giuseppe Toniolo 20', 06680261,('segreteriacorsi','@','ifcsl','.','com'), 'IFCSL' );



INSERT INTO public."COURSE_COMPANY"
("ID_Course_Company","Address_Course_Company","Telephone_Course_Company","Email_Course_Company")    
VALUES
(('IDCCP',5521896351),  'MilanoFiori, Strada 1', 02 80672 674,('infonline','@','cegos','.','it'), 'Cegos' ); 



INSERT INTO public."COURSE_COMPANY"
("ID_Course_Company","Address_Course_Company","Telephone_Course_Company","Email_Course_Company")    
VALUES
(('IDCCP',4425502300),  NULL, NULL, NULL, 'Udemy' ); 




INSERT INTO public."COURSE_COMPANY"
("ID_Course_Company","Address_Course_Company","Telephone_Course_Company","Email_Course_Company")    
VALUES
(('IDCCP',8420365197),  NULL, NULL, ('press','@','duolingo','.','com'), 'Duolinguo' );    



INSERT INTO public."COURSE_COMPANY"
("ID_Course_Company","Address_Course_Company","Telephone_Course_Company","Email_Course_Company")    
VALUES
(('IDCCP',3030332568),  NULL, NULL, NULL, 'IELTS' ); 


INSERT INTO public."COURSE_COMPANY"
("ID_Course_Company","Address_Course_Company","Telephone_Course_Company","Email_Course_Company")    
VALUES
(('IDCCP',7894861503),  'Via Savoia 15', 06 8440051, ('inforoma','@','goethe','.','de'), 'Goethe Institute' ); 



INSERT INTO public."COURSE_COMPANY"
("ID_Course_Company","Address_Course_Company","Telephone_Course_Company","Email_Course_Company")    
VALUES
(('IDCCP',5200300189),  'Piazzale Rodolfo Morandi 2 ',  02 7645501, ('aica','@','aicanet','.','it'), 'AICA' ); 