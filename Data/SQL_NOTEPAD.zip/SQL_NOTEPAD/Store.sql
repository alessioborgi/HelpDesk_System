INSERT INTO public."STORE"
("ID_Store","Store_Type","Store_Modality","Address_Store", "Name_Store")    
VALUES
(('IDST',1145786699),  'Book Shop', 'Physical Store', 'Via di S. Basilio 72', 'Mondadori' );

INSERT INTO public."STORE"
("ID_Store","Store_Type","Store_Modality","Address_Store", "Name_Store")    
VALUES
(('IDST',3320150048),  'Book Shop', 'Online Store', NULL, 'Abebooks' );


INSERT INTO public."STORE"
("ID_Store","Store_Type","Store_Modality","Address_Store", "Name_Store")    
VALUES
(('IDST',4489226984),  'Supermarket','Physical Store','via Nelson Mandela 4', 'Coop' );



INSERT INTO public."STORE"
("ID_Store","Store_Type","Store_Modality","Address_Store", "Name_Store")    
VALUES
(('IDST',1114487520),  'Supermarket', 'Physical Store', 'Via Carlo Pirzio Biroli 37', 'Todis' );



INSERT INTO public."STORE"
("ID_Store","Store_Type","Store_Modality","Address_Store", "Name_Store")    
VALUES
(('IDST',5521896351),  'Supermarket', 'Physical Store', 'Via Michelino 59', 'Conad' );


INSERT INTO public."STORE"
("ID_Store","Store_Type","Store_Modality","Address_Store", "Name_Store")    
VALUES
(('IDST',4425502300),  'Book Shop', 'Physical Store', 'Viale Pasubio 5', 'Feltrinelli' );


INSERT INTO public."STORE"
("ID_Store","Store_Type","Store_Modality","Address_Store", "Name_Store")    
VALUES
(('IDST',8420365197),  'Book Shop', 'Online Store', NULL, 'Kindle' );


INSERT INTO public."STORE"
("ID_Store","Store_Type","Store_Modality","Address_Store", "Name_Store")    
VALUES
(('IDST',2254139988),  'Book Shop', 'Online Store', NULL, 'Audible' );



INSERT INTO public."STORE"
("ID_Store","Store_Type","Store_Modality","Address_Store", "Name_Store")    
VALUES
(('IDST',1248703652),  'Supermarket', 'Physical Store', 'Via Caldera 21', 'Carrefour' );


INSERT INTO public."STORE"
("ID_Store","Store_Type","Store_Modality","Address_Store", "Name_Store")    
VALUES
(('IDST',6429735520),  'Book Shop', 'Physical Store', 'Piazza dei Cinquecento 48','Borri Books' );