INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',3368452200),1, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',3334982201),2, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',2568974202),3, () );




INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',2457896203),4, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',99874563204)),5, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',2547930005),6, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',3368452206),7, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',598416907),8, () );




INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',2579031408),9, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',2563010009),10, () );



INSERT INTO public."EMPLOYEE"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',7789430210),11, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',6363412011),12, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',1487956212),13, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',0002648713),14, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',9978632414),15, () );



INSERT INTO public."EMPLOYEE"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',8932014615),16, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',2598745616),17, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',4879652117),18, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',6987563218),19, () );


INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',9876543019),20, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',7890712320),21, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',9987102321),22, () );




INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',7365481922),23, () );



INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',1290853623),24, () );




INSERT INTO public."1ST_LEVEL_TECHNICIAN"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',5987641224),25, () );


INSERT INTO public."EMPLOYEE"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',78192036725),26, () );



INSERT INTO public."EMPLOYEE"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',5987641226),27, () );



INSERT INTO public."EMPLOYEE"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',69876324127),28, () );



INSERT INTO public."EMPLOYEE"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',6793071628),29, () );


INSERT INTO public."EMPLOYEE"
( "ID_Tech_1","Number_Workstation","ID_Account_Manager")
VALUES
(('IDWT1',1092854629),30, () );