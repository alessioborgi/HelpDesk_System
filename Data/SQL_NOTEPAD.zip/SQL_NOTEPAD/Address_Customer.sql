INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")
VALUES
(('IDCU',5597423015),  'Via Roccella Jonica', 10, 10098);


INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")  
VALUES
(('IDCU',5521896351),  'Via Roma', 112, 00165);

--------------------------------------------------------------------------------
INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")    
VALUES
(('IDCU',4425502300),  'Via Giuseppe Mazzini', 6, 15543 );

-----------------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")   
VALUES
(('IDCU',8420365197),  'Viale di Morena',12, 99876 );

---------------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")   
VALUES
(('IDCU',7551036521),  'Via Col di Lana', 17, 00984 );

-----------------------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")    
VALUES
(('IDCU',5841236044),  'Via Lucrezia Romana', 120, 00211);

-----------------------------------------------------------------------------------------------


INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")    
VALUES
(('IDCU',7551036522),  'Viale JF Kennedy', 55, 00189 );

-----------------------------------------------------------------------------------------------



INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")  
VALUES
(('IDCU',5841236044),  'Via Orsini', 6, 00144);


-----------------------------------------------------------------------------------------------


INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer") 
VALUES
(('IDCU',6429735520),  'Via Torquato Tasso', 19, 00876);


-----------------------------------------------------------------------------------------------


INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")    
VALUES
(('IDCU',3256458961),  'Viale Palmiro Togliatti', 88, 00444);

-----------------------------------------------------------------------------------------------


INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")  
VALUES
(('IDCU',2548703695),  'Via Cavour', 15,  00223 );


-----------------------------------------------------------------------------------------------


INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")   
VALUES
(('IDCU',3492649726),  'Via Giovanni Bellezza', 56, 00944);

-----------------------------------------------------------------------------------------------


INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")    
VALUES
(('IDCU',5558412036),  'Via Cristoforo Colombo', 73, 00331 );

-----------------------------------------------------------------------------------------------


INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")  
VALUES
(('IDCU',9951035745),  'Via Giuseppe Garibaldi', 13, 55601);


-------------------------------------------------------------------------------------


INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")   
VALUES
(('IDCU',7726354926),  'Via Venezia', 11, 77234 );

-------------------------------------------------------------------------------------------


INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")    
VALUES
(('IDCU',33684522109),  'Piazzale Armstrong', 62, 66432 );


---------------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")   
VALUES
(('IDCU',220168455),  'Via Croazia', 9, 00966 );

--------------------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")    
VALUES
(('IDCU',1234573560),  'Viale Parigi', 33, 44410  );

-----------------------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")   
VALUES
(('IDCU',4536782945),  'Via Renzo Piano', 65, 00017  );

------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")  
VALUES
(('IDCU',3030332568),  'Viale Picasso', 98, 46010 );

------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")  
VALUES
(('IDCU',4646522109),  'Via Visconti', 60, 18010 );

------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")  
VALUES
(('IDCU',7784520036),  'Via Cancelliera', 9, 29016 );

------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")  
VALUES
(('IDCU',5139875098),  'Via delle Banzole', 11, 36511 );

------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")  
VALUES
(('IDCU',7894861503),  'Piazza Caprara', 33, 55542 );

------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")   
VALUES
(('IDCU',5200300189),  'Via Altabella', 24, 09855 );


------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")  
VALUES
(('IDCU',5987612034),  'Viale di Azzogardino', 54, 00966 );


------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")   
VALUES
(('IDCU',6354289076),  'Via Battisasso', 20,  01087 );

------------------------------------------------------------------------------


INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")   
VALUES
(('IDCU',4462573109),  'Via dei Vetturini', 9, 00076 );


------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")  
VALUES
(('IDCU',8796521034),  'Via Calcavinazzi', 7, 00043 );


---------------------------------------------------------------------------------------

INSERT INTO public."ADDRESS_CUSTOMER"
("ID_Customer","Address_Customer","Flat_Number_Customer","ZIP_Code_Customer")   
VALUES
(('IDCU',45489662310),  'Via Santa Apollonia', 11, 00433 );