INSERT INTO public."TECHNOLOGY_COMPANY"
("ID_Company_tech", "Category_Tech_Company","Address_Tech_Company", "Name_Company_Tech")    
VALUES
(('IDTHC',6429735520),  'Various', '10600 N Tantau Ave', 'Apple' );

-------------------------------------------------------------------------------------------

INSERT INTO public."TECHNOLOGY_COMPANY"
("ID_Company_tech", "Category_Tech_Company","Address_Tech_Company", "Name_Company_Tech")    
VALUES
(('IDTHC',5841236044),  'Various', 'Via Mike Bongiorno 9' , 'Samsung' );


-------------------------------------------------------------------------------------------------

INSERT INTO public."TECHNOLOGY_COMPANY"
("ID_Company_tech", "Category_Tech_Company","Address_Tech_Company", "Name_Company_Tech")    
VALUES
(('IDTHC',7551036521),  'Telephony', 'Online', 'Oppo' );

----------------------------------------------------------------------------------------------

INSERT INTO public."TECHNOLOGY_COMPANY"
("ID_Company_tech", "Category_Tech_Company","Address_Tech_Company", "Name_Company_Tech")    
VALUES
(('IDTHC',5597423015),  'PC', 'Online', 'Asus' );

------------------------------------------------------------------------------------------------

INSERT INTO public."TECHNOLOGY_COMPANY"
("ID_Company_tech", "Category_Tech_Company","Address_Tech_Company", "Name_Company_Tech")    
VALUES
(('IDTHC',5521896351),  'Various', 'Via Achille Campanile n 73', 'HP' );

---------------------------------------------------------------------------------------------

INSERT INTO public."TECHNOLOGY_COMPANY"
("ID_Company_tech", "Category_Tech_Company","Address_Tech_Company", "Name_Company_Tech")    
VALUES
(('IDTHC',4425502300),  'Various', 'Via Lorenteggio 240', 'Huawei' );

------------------------------------------------------------------------------------------------

INSERT INTO public."TECHNOLOGY_COMPANY"
("ID_Company_tech", "Category_Tech_Company","Address_Tech_Company", "Name_Company_Tech")    
VALUES
(('IDTHC',8420365197),  'Various', 'Via San Bovio 3', 'Lenovo' );


-------------------------------------------------------------------------------------

INSERT INTO public."TECHNOLOGY_COMPANY"
("ID_Company_tech", "Category_Tech_Company","Address_Tech_Company", "Name_Company_Tech")    
VALUES
(('IDTHC',4356278190),  'Various', 'Viale Pasubio 21', 'Microsoft' );