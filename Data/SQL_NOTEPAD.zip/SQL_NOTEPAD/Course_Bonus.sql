INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',8420365197),  50, 2021-03-10, '2021-02-19 23:54:00');



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',2259875632), 50, 2023-08-17,  NULL);


INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',3365487210), 50, 2022-07-19,  '2020-10-15 10:55:08');



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',445872105), 80, 2019-11-30,  '2022-02-19 22:11:37');


INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',0025748961), 80,  2021-06-19,  '2022-02-19 06:33:33');


INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',4896100257), 80, 2026-05-02,  NULL);



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',1578964523), 100, 2023-03-10,  NULL);



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',4485627895), 100, 2024-01-01,  NULL);


INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',2789544856), 100, 2023-12-12,  '2022-02-19 17:34:03');



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',4685627519), 150, 2021-09-11,  '2022-02-19 20:35:47');



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',7885145871), 150, 2024-08-16,  '2022-02-19 11:01:09');



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',7885100098), 150, 2025-02-06,  '2020-10-13 22:20:07');



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',5512789645), 200, 2022-10-09,  '2022-01-20 07:48:39');



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',4471520367), 200, 2026-09-15,  NULL);



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',2036447158), 200, 2011-09-19,  '2009-11-17 21:56:54');



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',2001548697), 300, 2022-08-17,  '2021-07-19 11:45:52');



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',1117845200), 300, 2020-10-21,  '2019-11-08 22:00:00');



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',4520011178), 300,2005-02-17,  '2003-05-13 07:48:39');



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',5558463251), 500, 2023-10-15,  '2021-11-05 08:33:54');



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',5897451263), 500, 2022-06-30,  '2020-08-09 10:55:08');



INSERT INTO public."COURSE_BONUS"
("ID_Benefit_Courses_Bonus","Value_Courses_Bonus","Expiry_Date_Bonus","Date_Time_Usage")  
VALUES
(('IDBCB',4458726310), 500, 2021-01-19,  '2019-04-11 12:38:00');