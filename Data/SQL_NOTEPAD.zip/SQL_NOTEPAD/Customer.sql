INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")
VALUES
(('IDCU',5597423015),  'Luca', 'Rossi', 'luca.rossi', '12345', 'Platinum' );


INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")   
VALUES
(('IDCU',5521896351),  'Giada', 'Esposito', 'giada.esposito', 'ge556', 'Silver' );

--------------------------------------------------------------------------------
INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',4425502300),  'Sara', 'Capasso', 'sara.capasso', '248sc', 'Gold' );

-----------------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',8420365197),  'Flavio', 'Molinari', 'flavio.molinari', '2210fm', 'Metal' );

---------------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',7551036521),  'Giovanni', 'Mercuri', 'giovanni.mercuri', '00000', 'Platinum' );

-----------------------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',5841236044),  'Simone', 'Antonioli', 'simone.antonioli', '88sant', 'Gold' );

-----------------------------------------------------------------------------------------------


INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',7551036522),  'Giacomo', 'Fede' 'giacomo.fede', '?67!gf', 'Platinum' );

-----------------------------------------------------------------------------------------------



INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',5841236044),  'Alessia', 'Telaco', 'alessia.telaco', '245?pth', 'Metal' );


-----------------------------------------------------------------------------------------------


INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',6429735520),  'Iole', 'Fiorillo', 'iole.fiorillo', '**987_98', 'Metal' );


-----------------------------------------------------------------------------------------------


INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',3256458961),  'Gianna', 'Mastracci', 'gianna.mastracci', 'gmast2209', 'Silver' );

-----------------------------------------------------------------------------------------------


INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',2548703695),  'Stefano', 'Musella', 'stefano.musella', 'stefmus66', 'Bronze' );


-----------------------------------------------------------------------------------------------


INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',3492649726),  'Lucia', 'Noce', 'lucia.noce', '??lucia!!', 'Bronze' );

-----------------------------------------------------------------------------------------------


INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',5558412036),  'Claudio', 'Celani', 'claudio.celani', '1578claudio', 'Gold' );

-----------------------------------------------------------------------------------------------


INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',9951035745),  'Martina', 'Arcangelo', 'martina.arcangelo', '1789parigi', 'Metal' );


-------------------------------------------------------------------------------------


INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',7726354926),  'Simona', 'Bernardi', 'simona.bernardi', '1806simona', 'Platinum' );

-------------------------------------------------------------------------------------------


INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',3368452210),  'Giustino', 'Galli', 'giustino.galli', 'giustygalli', 'Silver' );


---------------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',220168455),  'Maria', 'Santoro', 'maria.santoro', 'mnbvcxz', 'Bronze' );

--------------------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',1234573560),  'Ilaria', 'Bianco', 'ilaria.bianco', '10101010', 'Metal' );

-----------------------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',4536782945),  'Ilenia', 'Caruso', 'ilenia.caruso', '1207ilenia', 'Metal' );

------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',3030332568),  'Marco', 'Serra', 'marco.serra', '??tymarco', 'Gold' );

------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',4646522109),  'Angelo', 'Fontana', 'angelo.fontana', 'jjjjj99', 'Platinum' );

------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',7784520036),  'Laila', 'Testa', 'laila.testa', '1515175', 'Metal' );

------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',5139875098),  'Anna', 'Rizzi', 'anna.rizzi', 'anna', 'Gold' );

------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',7894861503),  'Federico', 'Mazza', 'federico.mazza', 'fedemazza', 'Silver' );

------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',5200300189),  'Carlo', 'Giordano', 'carlo.giordano', 'giordano00', 'Silver' );


------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',5987612034),  'Sonia', 'Conti', 'sonia.conti', '99qwerty', 'Gold' );


------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',6354289076),  'Giuseppe', 'Mancini', 'giuseppe.mancini', 'giusman2000', 'Metal' );

------------------------------------------------------------------------------


INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',4462573109),  'Antonella', 'Fiorucci', 'antonella.fiorucci', 'ììlkke5', 'Gold' );


------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',8796521034),  'Celeste', 'Greco', 'celeste.greco', 'òdhsyn99', 'Platinum' );


---------------------------------------------------------------------------------------

INSERT INTO public."CUSTOMER"
("ID_Customer","Name_Customer","Surname_Customer","Username_Customer","Password_Customer","Level_Customer")    
VALUES
(('IDCU',4548966230),  'Gloria', 'Rosati', 'gloria.rosati', 'glros55è', 'Gold' );