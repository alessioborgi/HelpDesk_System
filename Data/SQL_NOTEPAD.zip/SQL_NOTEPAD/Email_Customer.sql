INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")
VALUES
(('IDCU',5597423015), ('luca.rossi', '@','gmail', '.', 'com'));


INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")   
VALUES
(('IDCU',5521896351),  ('giada.esposito', '@','gmail', '.', 'com'))

--------------------------------------------------------------------------------
INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',4425502300),  ('sara.capasso', '@','gmail', '.', 'com'));

-----------------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',8420365197),  ('flavio.molinari', '@','gmail', '.', 'com'));

---------------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',7551036521),  ('giovanni.mercuri', '@','gmail', '.', 'com'));

-----------------------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',5841236044),  ('simone.antonioli', '@','gmail', '.', 'com'));

-----------------------------------------------------------------------------------------------


INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',7551036522),  ('giacomo.fede', '@','gmail', '.', 'com'));

-----------------------------------------------------------------------------------------------



INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',5841236044),  ('alessia.telaco', '@','gmail', '.', 'com'));


-----------------------------------------------------------------------------------------------


INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',6429735520),  ('iole.fiorillo', '@','gmail', '.', 'com'));


-----------------------------------------------------------------------------------------------


INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',3256458961),  ('gianna.mastracci',  '@','gmail', '.', 'com') );

-----------------------------------------------------------------------------------------------


INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',2548703695),  ('stefano.musella', '@','gmail', '.', 'com') );


-----------------------------------------------------------------------------------------------


INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',3492649726),  ('lucia.noce',  '@','gmail', '.', 'com') );

-----------------------------------------------------------------------------------------------


INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',5558412036),  ('claudio.celani', '@','gmail', '.', 'com') );

-----------------------------------------------------------------------------------------------


INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',9951035745),  ('martina.arcangelo', '@','gmail', '.', 'com'));


-------------------------------------------------------------------------------------


INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',7726354926),  ('simona.bernardi', '@','gmail', '.', 'com'));

-------------------------------------------------------------------------------------------


INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',3368452210),  ('giustino.galli', '@','gmail', '.', 'com'));


---------------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',220168455),  ('maria.santoro', '@','gmail', '.', 'com') );

--------------------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',1234573560),  ('ilaria.bianco', '@','gmail', '.', 'com'));

-----------------------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',4536782945),  ('ilenia.caruso', '@','gmail', '.', 'com'));

------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',3030332568),  ('marco.serra', '@','gmail', '.', 'com') );

------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',4646522109),  ('angelo.fontana', '@','gmail', '.', 'com') );

------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',7784520036),  ('laila.testa',  '@','gmail', '.', 'com') );

------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',5139875098),  ('anna.rizzi', '@','gmail', '.', 'com'));

------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',7894861503),  ('federico.mazza',  '@','gmail', '.', 'com'));

------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',5200300189),  ('carlo.giordano',  '@','gmail', '.', 'com') );


------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',5987612034),  ('sonia.conti',  '@','gmail', '.', 'com') );


------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',6354289076),  ('giuseppe.mancini', '@','gmail', '.', 'com') );

------------------------------------------------------------------------------


INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',4462573109),  ('antonella.fiorucci',  '@','gmail', '.', 'com') );


------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',8796521034),  ('celeste.greco',  '@','gmail', '.', 'com') );


---------------------------------------------------------------------------------------

INSERT INTO public."EMAIL_CUSTOMER"
("ID_Customer","Email_Address_Customer")    
VALUES
(('IDCU',4548966230),  ('gloria.rosati', '@','gmail', '.', 'com'));