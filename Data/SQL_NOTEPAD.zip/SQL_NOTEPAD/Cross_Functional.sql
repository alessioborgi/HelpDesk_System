INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',52600),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',94501),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',23202),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',58503),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',26304),'Finance' );


INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',45805),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',45606),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',63507),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',85908),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',85709),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',65210),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',65311),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',35212),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',32613),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',84514),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',54515),'Finance' );


INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',53516),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',52517),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',45818),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWFIN',65819),'Finance' );




INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',65400),'Finance' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',56201),'Human Resources' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',54102),'Human Resources' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',30203),'Human Resources' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',57804),'Human Resources' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',65405),'Human Resources' );


INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',56006),'Human Resources' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',96307),'Human Resources' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',62508),'Human Resources' );


INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',43609),'Human Resources' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',30210),'Human Resources' );



INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',21411),'Human Resources' );


INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',98712),'Human Resources' );


INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',24113),'Human Resources' );


INSERT INTO public."CROSS_FUNCTIONAL"
( "ID_Cross_Functional","Type_Cross_Functional")
VALUES
(('IDWHR',85614),'Human Resources' );