INSERT INTO public."BANK"
("ID_Bank", "Reference_Email","Reference_Phone", "Reference_Address", "Bank_Type", "Name_Bank")    
VALUES
(('IDBK',1145786699),  NULL, NULL, NULL, 'Ether' );


INSERT INTO public."BANK"
("ID_Bank", "Reference_Email","Reference_Phone", "Reference_Address", "Bank_Type", "Name_Bank")    
VALUES
(('IDBK',3320150048),  ('reclami','@','unicredit','.','eu'), 800575757,'Piazza Gae Aulenti 3','Credit Company', 'Unicredit' );



INSERT INTO public."BANK"
("ID_Bank", "Reference_Email","Reference_Phone", "Reference_Address", "Bank_Type", "Name_Bank")    
VALUES
(('IDBK',4489226984),  ('assistenza.reclami','@','intesasanpaolo','.','com'), 800303303,'Piazza San Carlo 156,','Credit Company',  'Intesa San Paolo' );



INSERT INTO public."BANK"
("ID_Bank", "Reference_Email","Reference_Phone", "Reference_Address", "Bank_Type", "Name_Bank")    
VALUES
(('IDBK',1114487520),  ('Centro_relazioni_clientela','@','bnlmail','.','com'), 060060,'Via Vittorio Veneto 119', 'Banca Nazionale del Lavoro' );


INSERT INTO public."BANK"
("ID_Bank", "Reference_Email","Reference_Phone", "Reference_Address", "Bank_Type", "Name_Bank")    
VALUES
(('IDBK',5521896351),  NULL, NULL, NULL, 'Stock Company', 'BitCoin' );


INSERT INTO public."BANK"
("ID_Bank", "Reference_Email","Reference_Phone", "Reference_Address", "Bank_Type", "Name_Bank")
VALUES
(('IDBK',4425502300), ('info','@','mps','.','it'), 0577294111, ' Piazza Salimbeni 3', 'Credit Company', 'Banca Monti dei paschi di Siena');


INSERT INTO public."BANK"
("ID_Bank", "Reference_Email","Reference_Phone", "Reference_Address", "Bank_Type", "Name_Bank")  
VALUES
(('IDBK',8420365197), NULL, NULL, NULL,'Stock Company', 'Shiba Inu' );



INSERT INTO public."BANK"
("ID_Bank", "Reference_Email","Reference_Phone", "Reference_Address", "Bank_Type", "Name_Bank")    
VALUES
(('IDBK',2254139988), ('csr','@','enel','.','com'),  0683051,'viale Regina Margherita 125','Stock Company', 'ENEL' );



INSERT INTO public."TECHNOLOGY_COMPANY"
("ID_Bank", "Reference_Email","Reference_Phone", "Reference_Address", "Bank_Type", "Name_Bank")  
VALUES
(('IDBK',1248703652), ('dg.bplazio','@','legalmail','.','it'), 069636229,'Via del Comune 59', 'Credit Company', 'Banca Popolare del Lazio' );



INSERT INTO public."TECHNOLOGY_COMPANY"
("ID_Bank", "Reference_Email","Reference_Phone", "Reference_Address", "Bank_Type", "Name_Bank")
VALUES
(('IDBK',6429735520), ('clienti','@','enigaseluce','.','com'), 800900400,'Piazzale Enrico Mattei 1', 'Stock Company',  'ENI' );