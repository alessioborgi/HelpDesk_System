INSERT INTO public."PPE"
("ID_PPE", "Size_PPE","Type_PPE","Visor","Brand_PPE")    
VALUES
(('IDPPE',1234568907), 'S', 'Gloves', False, 'Nike');


INSERT INTO public."PPE"
("ID_PPE", "Size_PPE","Type_PPE","Visor","Brand_PPE")    
VALUES
(('IDPPE',2539652965), 'L', 'Safety_Jacket', False, 'Adidas');



INSERT INTO public."PPE"
("ID_PPE", "Size_PPE","Type_PPE","Visor","Brand_PPE")    
VALUES
(('IDPPE',2495137594), 'M', 'Helmet', True, 'Nolan');



INSERT INTO public."PPE"
("ID_PPE", "Size_PPE","Type_PPE","Visor","Brand_PPE")    
VALUES
(('IDPPE',5137528946), 'S', 'Safety_Shoes', False, 'Nike');


INSERT INTO public."PPE"
("ID_PPE", "Size_PPE","Type_PPE","Visor","Brand_PPE")    
VALUES
(('IDPPE',2287446135), 'L', 'Safety_Jacket', False, 'Nike');



INSERT INTO public."PPE"
("ID_PPE", "Size_PPE","Type_PPE","Visor","Brand_PPE")    
VALUES
(('IDPPE',6429735520), 'M', 'Gloves', False, 'SafetyCompany');



INSERT INTO public."PPE"
("ID_PPE", "Size_PPE","Type_PPE","Visor","Brand_PPE")    
VALUES
(('IDPPE',2496621583), 'M', 'Safety_Shoes', False, 'Puma');




INSERT INTO public."PPE"
("ID_PPE", "Size_PPE","Type_PPE","Visor","Brand_PPE")    
VALUES
(('IDPPE',5586137419), 'L', 'Gloves', False, 'SafetyCompany');




INSERT INTO public."PPE"
("ID_PPE", "Size_PPE","Type_PPE","Visor","Brand_PPE")    
VALUES
(('IDPPE',4496678210), 'S', 'Helmet', False, 'Caberg');