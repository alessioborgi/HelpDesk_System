-- FUNCTION: public.check_cus_lev()

-- DROP FUNCTION IF EXISTS public.check_cus_lev();

CREATE OR REPLACE FUNCTION public.check_cus_lev()
    RETURNS trigger
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE NOT LEAKPROOF
AS $BODY$
 DECLARE 
 DECLARE
    count_customer integer;
 
 BEGIN
 
   SELECT "ID_Customer", COUNT ("ID_Coustomer") as count_customer
	FROM public."TICKET" 
	WHERE "ID_Customer" = new."ID_Customer"
	GROUP BY "ID_Customer";
	
	IF count_customer <= 5 THEN 
		UPDATE public."CUSTOMER" SET public."CUSTOMER"."level_value" = 'Metal';
	END IF;
	IF count_customer <= 10 THEN 
		UPDATE  public."CUSTOMER" SET public."CUSTOMER"."level_value" = 'Bronze';
	END IF; 
	IF count_customer <= 15 THEN 
		UPDATE  public."CUSTOMER" SET public."CUSTOMER"."level_value" = 'Silver';
	END IF;
	IF count_customer <= 20 THEN 
		UPDATE  public."CUSTOMER" SET public."CUSTOMER"."level_value" = 'Gold';
	END IF;
	IF count_customer > 20 THEN 
		UPDATE  public."CUSTOMER" SET public."CUSTOMER"."level_value" = 'Platinum';
	END IF;
 END; 
 
$BODY$;

ALTER FUNCTION public.check_cus_lev()
    OWNER TO postgres;