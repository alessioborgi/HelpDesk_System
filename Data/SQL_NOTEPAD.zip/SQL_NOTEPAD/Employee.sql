-----1ST TECH

INSERT INTO public."EMPLOYEE"
( "ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources")    
VALUES
(('IDWT1',3368452200), 'Metal', 'Workforce', 'Giada', 'Galli', 'IT06C0300203280943841273771','giada.galli', 'giustygalli', NULL, () );


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',3334982201), 'Bronze', 'Workforce', 'Emanuele', 'Milazzo', 'IT24U0300203280189757614114','emanuele.milazzo', 'ndiwfiuwef', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',2568974202), 'Silver', 'Workforce', 'Elena', 'Ferroni', 'IT79L0300203280971828347582','elena.ferroni', 'n3948br', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',2457896203), 'Gold', 'Workforce', 'Valeria', 'Pozzi', 'IT91U0300203280318275621924','valeria.pozzi', 'fn3u29i2', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',99874563204), 'Platinum', 'Workforce', 'Silvia', 'Mininni', 'IT47J0300203280632619292627','silvia.mininni', 'd5sedw6ef', NULL, () );



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',2547930005), 'Metal', 'Workforce', 'Stefano', 'Rizzo', 'IT92F0300203280131615447963','stefano.rizzo', 'dn390n9', NULL, () );



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',3368452206), 'Bronze','Workforce', 'Daria', 'Moretti', 'IT38R03002032804695536689','daria.moretti', 'j291d032j', NULL, () );




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',598416907), 'Bronze','Workforce', 'Luca', 'Barbieri', 'IT76T0300203280968916824439','luca.barbieri', '1594856nwo', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',2579031408), 'Platinum','Workforce', 'Gloria', 'Lombardi', 'IT51G0300203280254933474514','gloria.lombardi', 'db8723h9', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',2563010009), 'Silver','Workforce', 'Lorenzo', 'Leone', 'IT19S0300203280373995998884','lorenzo.leone', 'fj390j94', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',7789430210), 'Gold','Workforce', 'Simone', 'Gentile', 'IT82K0300203280446614674597','simone.gentile', 'fj32932', NULL, () );



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',6363412011), 'Gold','Workforce', 'Andrea', 'Marchetti', 'IT95S0300203280537978318152','andrea.marchetti', 'dj3838d3', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',1487956212), 'Silver','Workforce', 'Mauro', 'Coppola', 'IT22C0300203280592945854521','mauro.coppola', 'd229m0nw', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',0002648713), 'Gold','Workforce', 'Sonia', 'Vitale', 'IT11P0300203280717777531961','sonia.vitale', 'n93n93d2', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',9978632414), 'Metal','Workforce', 'Micheal', 'Longo', 'IT42W0300203280349643142965','micheal.longo', 'f39n8f39', NULL, () );



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',8932014615), 'Platinum','Workforce', 'Dalila', 'Leoni', 'IT77Y0300203280448356944881','dalila.leone', 'j291d03ll', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',2598745616), 'Metal','Workforce', 'Tommaso', 'Serra', 'IT55Y0300203280288667575951','tommaso.serra', 'jf3902f', NULL, () );



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',4879652117), 'Bronze','Workforce', 'Federica', 'Fabbri', 'IT80D0300203280826543571752','federica.fabbri', 'c329238', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',6987563218), 'Gold','Workforce', 'Federico', 'Parisi', 'IT60J0300203280351162776976','federico.parisi', 'n389fn39', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',9876543019), 'Bronze','Workforce', 'Giuseppe', 'Villa', 'IT93J0300203280974652858855','giuseppe.villa', 'vn439n439', NULL, () );



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',7890712320), 'Silver','Workforce', 'Giovanni', 'De Santis', 'IT83M0300203280663368483285','giovanni.desantis', 'f3892bf', NULL, () );


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',9987102321), 'Platinum','Workforce', 'Gianfranco', 'Masi', 'IT02U0300203280882254496956','gianfranco.masi', 'cn3289cn3', NULL, () );



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',7365481922), 'Metal','Workforce', 'Gianluca', 'Cattaneo', 'IT72M0300203280482343885781','gianluca.cattaneo', 'niowncio', NULL, () );



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',1290853623), 'Metal','Workforce', 'Simona', 'Mazza', 'IT97Z0300203280794696458922','simona.mazza', 'd32fnnd', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',5987641224), 'Silver','Workforce', 'Paolo', 'Grassi', 'IT86S0300203280799993852492','paolo.grassi', 'dn32dnop', NULL, () );



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',78192036725), 'Bronze','Workforce', 'Paola', 'Carbone', 'IT48T0300203280473448432556','paola.carbone', 'n3829v2ni', NULL, () );


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',5987641226), 'Silver','Workforce', 'Stella', 'Amato', 'IT41U0300203280765437442717','stella.amato', 'jf932nv2', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',69876324127), 'Gold','Workforce', 'Sofia', 'Silvestri', 'IT27V0300203280287698666616','sofia.silvestri', 'dn3wonf', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',6793071628), 'Platinum','Workforce', 'Serena', 'Testa', 'IT17R0300203280396293825445','serena.testa', 'n92f32nf', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT1',1092854629), 'Gold','Workforce', 'Michele', 'Pellegrino', 'IT10S0300203280868216378763','michele.pellegrino', 'nf9182fb', NULL, () );




--------2nd_Tech

INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9765359800), 'Bronze','Workforce', 'Silvio', 'Barone', 'IT31D0300203280812169763822','silvio.barone', 'nf923nw2', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',5789462101), 'Silver','Workforce', 'Gioia', 'Bellini', 'IT27U0300203280763619679556','gioia.bellini', 'nd3200n2', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9986541202), 'Metal','Workforce', 'Ilario', 'Basile', 'IT31D0300203280812169763822','ilario.basile', 'dn219n1', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9963352403), 'Metal','Workforce', 'Girolamo', 'Ferrelli', 'IT97S0300203280636459752847','girolamo.ferrelli', 'd92nf2a', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',7784563204), 'Gold','Workforce', 'Leila', 'Fiorentini', 'IT56R0300203280213683997363','leila.fiorentini', 'ppp081nd', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","U
sername_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',6874152305), 'Bronze','Workforce', 'Francesca', 'Fiore', 'IT06S0300203280554925725679','francesca.fiore', 'j90noinm', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',8854263106), 'Gold','Workforce', 'Giorgia', 'Rossellini', 'IT54N0300203280638387776962','giorgia.rossellini', 'nd32nfood', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',1188975607), 'Gold','Workforce', 'Giorgio', 'Rossetti', 'IT46M0300203280814963687598','giorgio.rossetti', 'nf29nvowe', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9987456308), 'Platinum','Workforce', 'Claudio', 'De Rosa', 'IT33X0300203280241171731236','claudio.derosa', 'cllq9wd', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',0004589609), 'Gold','Workforce', 'Eugenio', 'Guerra', 'IT91V0300203280422294144975','eugenio.guerra', 'cn2of982m', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',1562456210), 'Metal','Workforce', 'Rocco', 'Caputo', 'IT88S0300203280747999161773','rocco.caputo', 'h8hniu', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9998746311), 'Bronze','Workforce', 'Rossella', 'Montanari', 'IT17P0300203280661176964368','rossella.montanari', 'bf823nfw', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9876522012), 'Gold','Workforce', 'Monica', 'Riva', 'IT02T0300203280849714745449','monica.riva', 'f28nefi', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',5554869513), 'Platinum','Workforce', 'Vittoria', 'Donati', 'IT72U0300203280611185316944','vittoria.donati', 'f2n8mieeiw', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9775634814), 'Silver','Workforce', 'Gaetano', 'Battaglia', 'IT14G0300203280254517231399','gaetano.battaglia', 'b28euiwu', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9987456315), 'Bronze','Workforce', 'Patrizio', 'Neri', 'IT92L0300203280572966267172','patrizio.neri', 'dn2iocwoe', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9876453216), 'Silver','Workforce', 'Patrizia', 'Sartori', 'IT03D0300203280961951654435','patrizia.sartori', '2vn39jw2', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9876543217), 'Metal','Workforce', 'Ester', 'Costantini', 'IT26Z0300203280351738643587','ester.costantini', '2nfioawafi', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',98745635118), 'Platinum','Workforce', 'Elettra', 'Milani', 'IT49R0300203280172799545768','elettra.milani', 'nowie3wf', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9875635119), 'Gold','Workforce', 'Alessandro', 'Pagano', 'IT06C0300203280989968112511','alessandro.pagano', 'fg2832i3', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',4896756220), 'Silver','Workforce', 'Filomena', 'Sorrentino', 'IT61F0300203280729992378919','filomena.sorrentino', 'gf822o', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',4111098721), 'Metal','Workforce', 'Elisa', 'Damico', 'IT52G0300203280395847378225','elisa.damico', '1bio2de', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9990768522), 'Metal','Workforce', 'Andrea', 'Ruggiero', 'IT42H0300203280459629631574','andrea.ruggiero', 'dm0j2kiw', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',4487965223), 'Platinum','Workforce', 'Francesco', 'Orlando', 'IT37Z0300203280348532963721','francesco.orlando', 'd17g1hi', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',1111899624), 'Silver','Workforce', 'Carla', 'Spiriti', 'IT30P0300203280957195755386','carla.spiriti', 'db19ooq2', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',7777889925), 'Metal','Workforce', 'Carlotta', 'Porcu', 'IT68P0300203280999886152617','carlotta.porcu', 'dn1ooiio2', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',5454663326), 'Bronze','Workforce', 'Chiara', 'Battipaglia', 'IT85L0300203280274923354154','chiara.battipaglia', 'db21892i', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',8787888827), 'Silver','Workforce', 'Vittoria', 'Lelli', 'IT82I0300203280479872872199','vittoria.lelli', 'db12u2ni', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',5556463828), 'Gold','Workforce', 'Gisella', 'Graziani', 'IT41R0300203280479931897988','gisella.graziani', 'db728h1ml', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',4446665529), 'Metal','Workforce', 'Aleandro', 'Di Carlo', 'IT49S0300203280948658793214','aleandro.dicarlo', 'b8f2ifi23', NULL, ());





INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',48975698530), 'Bronze','Workforce', 'Daniele
', 'Dallepiatte', 'IT45W0300203280757887715218','daniele.dallepiatte', 'x9vb6nml', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',8885642331), 'Gold','Workforce', 'Maurizio', 'Consolati', 'IT20G0300203280659979548621','maurizio.consolati', 'a29il0l0', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',6793289732), 'Metal','Workforce', 'Deborah', 'Conti', 'IT13A0300203280585916969729','deborah.conti', 'b9o23nojh', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',0912631033), 'Silver','Workforce', 'Athena', 'Cirillo', 'IT36R0300203280249957476262','athena.cirillo', 'l0l9j9jk', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',5428901434), 'Bronze','Workforce', 'Enrico', 'Bruno', 'IT92S0300203280157155386424','enrico.bruno', 'z45zx4', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',3334879535), 'Platinum','Workforce', 'Nicola', 'Boz', 'IT69A0300203280779566117296','nicola.boz', '82939jmi', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9998775636), 'Silver','Workforce', 'Gabriella', 'Bonini', 'IT28G0300203280574776328898','gabriella.bonini', 'b2oebniow', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',0002987637), 'Metal','Workforce', 'Gabriele', 'Amantini', 'IT25O0300203280245977113642','gabriele.amantini', 'n29832j', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9997846538), 'Bronze','Workforce', 'Anna', 'Daliasi', 'IT64G0300203280448381344266','anna.belloni', 'fn293fo2f', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',4848986539), 'Gold','Workforce', 'Beniamino', 'Abramo', 'IT49R0300203280699569473241','beniamino.abramo', 'h839hf', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',5889874540), 'Gold','Workforce', 'Gennaro', 'Varone', 'IT94E0300203280711564951469','gennaro.varone', 'no3nrio', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9696856241), 'Platinum','Workforce', 'Valentina', 'Siciliano', 'IT95V0300203280994577451397','valentina.siciliano', ' c2msoce3i', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',6639874542), 'Bronze','Workforce', 'Luigi', 'Renna', 'IT93N0300203280439952564362','luigi.renna', 'bx81xum', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9995554143), 'Metal','Workforce', 'Davide', 'Dottavio', 'IT19X0300203280472463366162','davide.dottavio', 'h839hf', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',0010105244), 'Platinum','Workforce', 'Noemi', 'Pecci', 'IT96V0300203280745465293895','noemi.pecci', 's222omo', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',1119898645), 'Bronze','Workforce', 'Morena', 'Pagani', 'IT62F0300203280368331421535','morena.pagani', 'nc893ni', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',4646963546), 'Gold','Workforce', 'Graziano', 'Melato', 'IT51H0300203280624578866866','graziano.melato', 'nc90ecnw2', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',3338787947), 'Silver','Workforce', 'Michele', 'Luperti', 'IT95V0300203280371479123697','michele.luperti', 'qnis289s', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',8282725648), 'Silver','Workforce', 'Mariona', 'Falletta', 'IT48E0300203280897456281723','mariona.falletta', 'k0kojmoow', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9686351749), 'Bronze','Workforce', 'Massimo', 'Gorini', 'IT19X0300203280961541452675','massimo.gorini', '2983enf2n', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',4879562350), 'Bronze','Workforce', 'Arianna', 'Loret', 'IT39X0300203280728963833448','arianna.loret', '3h2ud8i3ud', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',8874596551), 'Metal','Workforce', 'Fulvio', 'Calaciura', 'IT95K0300203280422468159589','fulvio.calaciura', 'hf3uihiu3', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9686523252), 'Metal','Workforce', 'Riccardo', 'Biancotto', 'IT09M0300203280528854887559','riccardo.biancotti', 'w7e82u3799', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',7979854253), 'Platinum','Workforce', 'Jacopo', 'Zucchini', 'IT93U0300203280126735229936','jacopo.zucchini', 'wiejdu526', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',6669898754), 'Gold','Workforce', 'Micaela', 'Pregnolato', 'IT81V0300203280394443942237','micaela.pregnolato', 'd2idahdue', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',7353624555), 'Metal','Workforce', 'Niccolò', 'Deodati', 'IT72A0300203280994672955723','niccolo.diodato', 'bv23bu2', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',7595863556), 'Metal','Workforce', 'Barbara', 'Vincenzi', 'IT90O0300203280462955631525','barbara.vincenzi', 'be812nbm', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',7985642657), 'Gold','Workforce', 'Bruno', 'Scuccato', 'IT31H0300203280612494649712','bruno.scuccato', 'x9fdjdoci', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',9875632558), 'Platinum','Workforce', 'Nadia', 'Rosa', 'IT93L0300203280173618534847','nadia.rosa', 'agofhuef', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))    
VALUES
(('IDWT2',8596741259), 'Silver','Workforce', 'Alessia', 'Monaco', 'IT32T0300203280725814161321','alessia.monaco', '82bu4ig', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWT2',2828978560), 'Gold','Workforce', 'Tania', 'Bianchini', 'IT06P0300203280952964878882','tania.bianchini', 'cn2ncjenw', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWT2',9785646261), 'Silver','Workforce', 'Mirko', 'Sales', 'IT14L0300203280536597868844','mirko.sales', 'b72cbeun', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWT2',0052486462), 'Platinum','Workforce', 'Gianna', 'Eleodori', 'IT73F0300203280118134143865','gianna.eleodori', 'hc3hend', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWT2',1489756263), 'Silver','Workforce', 'Ombretta', 'Spinelli', 'IT62L0300203280327426925681','ombretta.spinelli', 'bc3hn3dj', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWT2',7852466464), 'Metal','Workforce', 'Alberto', 'Giordani', 'IT34B0300203280859681426647','alberto.giordani', 'bce9icn83c', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWT2',9362451665), 'Gold','Workforce', 'Maria Luisa', 'Enea', 'IT02K0300203280793296894858','marialuisa.enea', 'cb3cni', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWT2',8202025166), 'Metal','Workforce', 'Luigina', 'Iannaccio', 'IT61G0300203280247111576888','Luigina.iannaccio', 'bc278nxi', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWT2',6854123067), 'Metal','Workforce', 'Benedetta', 'Iannetta', 'IT48T0300203280672243216761','benedetta.iannetta', 'cb28une', NULL, ());

INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWT2',9105658968), 'Platinum','Workforce', 'Iole', 'Zaghi', 'IT10U0300203280925875381777','iole.zaghi', 'bc289n3', NULL, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWT2',9063521469), 'Gold','Workforce', 'Sabina', 'Colasanti', 'IT66H0300203280913422859915','sabina.colasanti', 'b8en3d9jm', NULL, ());



-----ACCOUNTMANAGER

INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWAC',1578645200), 'Gold','Workforce', 'Bruna', 'Gasbarrini', 'IT61M0300203280913847599697','bruna.gasbarrini', 'h83f43hs', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWAC',5879462501), 'Silver','Workforce', 'Albertina', 'De Vincentis', 'IT45Z0300203280199824827869','albertina.devincentis', '39i8edmd', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWAC',9865748502), 'Metal','Workforce', 'Tamara', 'Pizzuti', 'IT51L0300203280485969745893','tamara.pizzuti', 'cn39hc3ic', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWAC',9787563203), 'Gold','Workforce', 'Diego', 'Mastrangelo', 'IT88D0300203280122874338578','diego.mastrangelo', 'h78h8nu', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWAC',7845956204), 'Metal','Workforce', 'Lorenzo', 'Pirandola', 'IT79P0300203280961258635491','lorenzo.pirandola', 'crtctv58', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWAC',8886594505), 'Platinum','Workforce', 'Andrea', 'Pinchera', 'IT62D0300203280558584937817','andrea.pinchera', 'ghynui789', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWAC',7989562306), 'Metal','Workforce', 'Maurizio', 'Gasbarrone', 'IT53C0300203280589943962565','maurizio.gasbarrone', 'h849rfmi', NULL, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWAC',7895451207), 'Silver','Workforce', 'Laura', 'Colucci', 'IT93H0300203280199728141347','laura.colucci', 'fhn3ir3mi', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWAC',1785965208), 'Gold','Workforce', 'Pierluigi', 'Raggini', 'IT70D0300203280614219838924','pierluigi.raggini', 'n3ci8xdj', NULL, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWAC',7989652309), 'Metal','Workforce', 'Filippo', 'Magliocca', 'IT66H0300203280913422859915','filippo.magliocca', 'n3iedexidj', NULL, ());



----BUSINESS MANAGER

INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',1896587500), 'Gold','Workforce', 'Daniela', 'Vetrano', 'IT94A0300203280173863233997','daniela.vetrano', 'fi3nfi3i', 01, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',5858258501), 'Metal','Workforce', 'Benedetto', 'Simeone', 'IT91U0300203280141571413922','benedetto.simeone', 'nejwnjnjh', 02, ());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',9696968602), 'Platinum','Workforce', 'Ilenia', 'Tata', 'IT45Q0300203280362634573348','ilenia.tata', 'fn3infi', 03, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',7989652503), 'Metal','Workforce', 'Tania', 'Pesce', 'IT18K0300203280676188356421','tania.pesce', 'nfo3infi3r', 04, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',2828522404), 'Gold','Workforce', 'Tonio', 'Pallante', 'IT18K0300203280676188356421','tonio.pallante', 'hf834nf', 05, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',9785623505), 'Platinum','Workforce', 'Italo', 'Mele', 'IT59F0300203280283356467648','italo.mele', 'weniowe', 06, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',6454352606), 'Silver','Workforce', 'Marcella', 'Lanzieri', 'IT77R0300203280792215426171','marcella.lanzieri', 'j93ejfej', 07, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',73512698507), 'Metal','Workforce', 'Giulia', 'Filippone', 'IT30A0300203280522722678819','giulia.filippone', 'j23jjdj', 08, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',2858483808), 'Platinum','Workforce', 'Giulio', 'Grimaldi', 'IT70C0300203280692922869211','giulio.grimaldi', 'c89hdn8', 09, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',1968759609), 'Bronze','Workforce', 'Pasquale', 'Iacobozzi', 'IT12Y0300203280288929967642','pasquale.iacobozzi', 'fgb378bfu', 10, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',8886353610), 'Metal','Workforce', 'Pasqualina', 'Sannino', 'IT61R0300203280445946343442','pasqualina.sannino', 'h3iendeuid', 11, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',1152635311), 'Gold','Workforce', 'Alessio', 'Castigliani', 'IT92C0300203280611192857523','alessio.castigliani', 'bf38fbe3fu', 12, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',7986352512), 'Metal','Workforce', 'Filippo', 'Carp', 'IT41J0300203280454342178517','filippo.carp', 'hn3894ri', 13, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',2868982513), 'Platinum','Workforce', 'Ian', 'Aiello', 'IT95Z0300203280196952448516','ian.aiello', 'n4rihei', 14, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',1828379514), 'Silver','Workforce', 'Celeste', 'Minicocci', 'IT87C0300203280195593336451','celeste.minicocci', '39hcneiemimj', 15, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',1719385915), 'Platinum','Workforce', 'Giulio', 'Agostinelli', 'IT28Z0300203280519858598418','giulio.agostinelli', 'hf398he8', 16, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',1757286816), 'Silver','Workforce', 'Matteo', 'Greco', 'IT68A0300203280266981271185','matteo.greco', 'b273eb23e', 17, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',1663526517), 'Gold','Workforce', 'Mattia', 'Biodillo', 'IT90Q0300203280318935567556','mattia.biodillo', 'n839n93i', 18, ());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',9393635218), 'Metal','Workforce', 'Rosalisa', 'Marinelli', 'IT05E0300203280566463442845','rosalisa.marinelli', 'fb83fh3f', 19, ());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWBC',7285962419), 'Gold','Workforce', 'Rita', 'Terenzi', 'IT69I0300203280626287451483','rita.terenzi', 'bf38bfe', 20,());



-----FINANCE
INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',1898652600), 'Gold','Workforce', 'Pablo', 'Chessa', 'IT63Q0300203280657996811822','pablo.chessa', 'bcuiercbeiu', NULL,());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',1758946501), 'Metal','Workforce', 'Loreto', 'Bracalente', 'IT24P0300203280412427899583','loreto.bracalante', 'bc3uin', NULL,());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',1968523202), 'Metal','Workforce', 'Elios', 'Florean', 'IT20B0300203280624795272246','elios.florean', 'vnc3nciro', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',1936258503), 'Silver','Workforce', 'Denis', 'Fini', 'IT89U0300203280215181137665','denis.fini', 'fbuibf4io', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',7985426304), 'Bronze','Workforce', 'Romina', 'Cannavò', 'IT83G0300203280988185351226','romina.cannavo', 'nceruin', NULL,());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',1936245805), 'Gold','Workforce', 'Mira', 'Cavalieri', 'IT76D0300203280561534271356','mira.cavalieri', 'bv3uruwnic', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',9998745606), 'Platinum','Workforce', 'Sebastiano', 'Buono', 'IT26P0300203280682772477629','sebastiano.buono', 'fn4398rn', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',2616263507), 'Metal','Workforce', 'Angelo', 'Vaccaro', 'IT69I0300203280626287451483','angelo.vaccaro', 'bcerunucn', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',7989485908), 'Metal','Workforce', 'Eni', 'Conti', 'IT86L0300203280373354731823','eni.conti', 'nc8ienci', NULL,());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',1869285709), 'Silver','Workforce', 'Travis', 'Aureli', 'IT20P0300203280654685468816','travis.aureli', 'hf3ccniecn', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',1578965210), 'Metal','Workforce', 'Cesare', 'Sciarra', 'IT93X0300203280463433979859','cesare.sciarra', 'fcb38mikemj', NULL,());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',5998765311), 'Platinum','Workforce', 'Alessandra', 'Walters', 'IT47G0300203280782945824619','alessandra.walters', 'bncuiern09', NULL,());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',5859635212), 'Silver','Workforce', 'Riccardo', 'Tartaglia', 'IT22H0300203280416994465431','riccardo.tartaglia', 'h84jfiok', NULL,());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',1896532613), 'Gold','Workforce', 'Francesco', 'Rossi', 'IT38F0300203280734693667178','francesco.rossi', 'h893hmmji', NULL,());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',5898784514), 'Gold','Workforce', 'Antonio', 'Del Papa', 'IT02W0300203280961119728531','antonio.delpapa', 'c938h8j', NULL,());




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',6968754515), 'Gold','Workforce', 'Jaco', 'Delogu', 'IT10U0300203280738422894581','jaco.delogu', 'b7ue3h7h', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',2525653516), 'Metal','Workforce', 'Peter', 'Ponzuoli', 'IT50E0300203280716846228326','peter.ponzuoli', 'buiebrucb', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',7895352517), 'Metal','Workforce', 'Luca', 'Mandal', 'IT59X0300203280926581762465','luca.mandal', 'vn8394rn', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',5898145818), 'Silver','Workforce', 'Christian', 'Notarnicola','IT07T0300203280894276847514','christian.notarnicola', '389neijdni', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWFIN',1789365819), 'Platinum','Workforce', 'Andrea', 'Piccinin', 'IT79A0300203280349323648323','andrea.piccinin', 'g48hg4i', NULL,());



------HR

INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',3587965400), 'Gold','Workforce', 'Luana', 'Principati', 'IT90Y0300203280919266264479','luana.principati', 'jd938ndj', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',35987456201), 'Gold','Workforce', 'Amadeo', 'Lauteri', 'IT72O0300203280198295982237','madeo.lauteri', 'd782m73d', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',2789654102), 'Metal','Workforce', 'Virginia', 'Lupi', 'IT76M0300203280993753821472','virginia.lupi', '78enubi', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',7985630203), 'Metal','Workforce', 'Fabio', 'Conti', 'IT85K0300203280739464819563','fabio.conti', 'k89bolnj', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',6565457804), 'Platinum','Workforce', 'Gabriele', 'Muzi', 'IT62Y0300203280817226396698','gabriele.muzi', '5cvfvuvg', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',7789965405), 'Gold','Workforce', 'Sauro', 'Stacchi', 'IT18N0300203280296473186486','sauro.stacchi', 'm7b8ojol', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',1112356006), 'Silver','Workforce', 'Rebecca', 'Lucchini', 'IT77D0300203280684631928696','rebecca.lucchini', 'l8uny78o', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',5558796307), 'Metal','Workforce', 'Moreno', 'Perilli', 'IT72O0300203280379959928861','moreno.perilli', 'gxdw!!njc', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',9868562508), 'Gold','Workforce', 'Shawn', 'Orlacchio', 'IT86V0300203280159723398989','shwn.orlacchio', '39ejl0xe', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',5848843609), 'Platinum','Workforce', 'Antonella', 'Nocioni', 'IT66K0300203280788499451119','antonella.nocioni', 'f89jme3', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',6644230210), 'Gold','Workforce', 'Antonello', 'Pallecchia', 'IT79A0300203280349323648323','antonello.pallecchia', '45dv6bg', NULL,());


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',3336521411), 'Metal','Workforce', 'Sara', 'Principato', 'IT96Q0300203280338869176185','sara.principato', 'j893jme', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',4455698712), 'Silver','Workforce', 'Giuletta', 'Minicocci', 'IT87A0300203280941185882231','giulietta.minicocci', 'bv8934nri', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',6663524113), 'Metal','Workforce', 'Jessica', 'Caruso', 'IT59V0300203280196946398113','jessica.caruso', 'n8923ndi', NULL,());



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDWHR',4478785614), 'Gold','Workforce', 'Enrnesto', 'Sedano', 'IT97D0300203280725263164758','ernesto.sedano', 'hf83hi', NULL,());



----LEADER




INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDL',0000000001), 'Platinum','Leadership', 'Eugen', 'Carinci', 'IT25X0300203280776822625579','eugen.carinci', 'ud8723d', 21,NULL);


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDL',0000000002), 'Silver','Leadership', 'Sandro', 'Basciani', 'IT55I0300203280589632881633','sandro.basciani', 'ò98nwed', 22,NULL);



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDL',0000000003), 'Gold','Leadership', 'Monia', 'Corradi', 'IT92C0300203280485788358193','monia.corradi', 'audb7ei', 23,NULL);



INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDL',0000000004), 'Gold','Leadership', 'Mohamed', 'Tomasi', 'IT98Q0300203280614377664467','mohamed.tomasi', 'vfyy8o7', 24,NULL);


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDL',00000000005), 'Platinum','Leadership', 'Emanuela', 'Coppetta', 'IT05R0300203280441862472663','emanuela.coppetta', 'b83ehnd', 25,NULL);


INSERT INTO public."EMPLOYEE"
("ID_Employee","Level_Employee","Employee_Type","Name_Employee","Surname_Employee","Number_Bank_Account","Username_Employee","Password_Employee","Parking_Number","ID_Human_Resources"))  
VALUES
(('IDL',0000000006), 'Platinum','Leadership', 'Emore', 'Chiola', 'IT44G0300203280453464816545','emore.chiola', 'h398fcmeif', 26,NULL);





