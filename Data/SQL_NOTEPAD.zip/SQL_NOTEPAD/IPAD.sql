INSERT INTO public."IPAD_BENEFIT"
("ID_Benefit_IPAD_Benefit","Assigned_Up_To_IPAD","OS_IPAD","Brand_IPAD","Width_IPAD","Height_IPAD","Price_IPAD","Inch_Screen_IPAD","ID_Company_Tech", "Model_IPAD_Benefit")  
VALUES
(('IDBIP',8420365197),  2023-12-31 , 'Android', 'Samsung', 149, 245, 200,10,('IDTHC',5841236044), 'Galaxy Tab A');



INSERT INTO public."IPAD_BENEFIT"
("ID_Benefit_IPAD_Benefit","Assigned_Up_To_IPAD","OS_IPAD","Brand_IPAD","Width_IPAD","Height_IPAD","Price_IPAD","Inch_Screen_IPAD","ID_Company_Tech", "Model_IPAD_Benefit")  
VALUES
(('IDBIP',2259875632),  2023-12-31, 'Android', 'Samsung', 124, 212,170, 8,('IDTHC',5841236044),'Galaxy Tab A7 Lite');



INSERT INTO public."IPAD_BENEFIT"
("ID_Benefit_IPAD_Benefit","Assigned_Up_To_IPAD","OS_IPAD","Brand_IPAD","Width_IPAD","Height_IPAD","Price_IPAD","Inch_Screen_IPAD","ID_Company_Tech", "Model_IPAD_Benefit")  
VALUES
(('IDBIP',2496621583),  2023-12-31, 'Android', 'Samsung', 213,126,500,8,('IDTHC',5841236044),'Galaxy Tab Active3 LTE Enterprise Edition');




INSERT INTO public."IPAD_BENEFIT"
("ID_Benefit_IPAD_Benefit","Assigned_Up_To_IPAD","OS_IPAD","Brand_IPAD","Width_IPAD","Height_IPAD","Price_IPAD","Inch_Screen_IPAD","ID_Company_Tech", "Model_IPAD_Benefit")  
VALUES
(('IDBIP',4496678210), 2024-12-31,'iPadOS','Apple', 134,195,600,8,('IDTHC',6429735520),'iPad mini');




INSERT INTO public."IPAD_BENEFIT"
("ID_Benefit_IPAD_Benefit","Assigned_Up_To_IPAD","OS_IPAD","Brand_IPAD","Width_IPAD","Height_IPAD","Price_IPAD","Inch_Screen_IPAD","ID_Company_Tech", "Model_IPAD_Benefit")  
VALUES
(('IDBIP',3365487210), 2023-12-31, 'iPadOS', 'Apple', 178,247,900,11,('IDTHC',6429735520),'iPad Pro 11');



INSERT INTO public."IPAD_BENEFIT"
("ID_Benefit_IPAD_Benefit","Assigned_Up_To_IPAD","OS_IPAD","Brand_IPAD","Width_IPAD","Height_IPAD","Price_IPAD","Inch_Screen_IPAD","ID_Company_Tech", "Model_IPAD_Benefit")  
VALUES
(('IDBIP',5841236044), 2023-12-31, 'iPadOS', 'Apple', 178,247,700,11,('IDTHC',6429735520),'iPad Air');



INSERT INTO public."IPAD_BENEFIT"
("ID_Benefit_IPAD_Benefit","Assigned_Up_To_IPAD","OS_IPAD","Brand_IPAD","Width_IPAD","Height_IPAD","Price_IPAD","Inch_Screen_IPAD","ID_Company_Tech", "Model_IPAD_Benefit")  
VALUES
(('IDBIP',7551036521),  2024-12-31, 'HUAWEI', 'Huawei', 286,184,600,12,('IDTHC',4425502300),'MatePad Pro');




INSERT INTO public."IPAD_BENEFIT"
("ID_Benefit_IPAD_Benefit","Assigned_Up_To_IPAD","OS_IPAD","Brand_IPAD","Width_IPAD","Height_IPAD","Price_IPAD","Inch_Screen_IPAD","ID_Company_Tech", "Model_IPAD_Benefit")  
VALUES
(('IDBIP',8420365197),  2023-12-31, 'HUAWEI', 'Huawei', 245,154,209,10,('IDTHC',4425502300), 'MatePad');





INSERT INTO public."IPAD_BENEFIT"
("ID_Benefit_IPAD_Benefit","Assigned_Up_To_IPAD","OS_IPAD","Brand_IPAD","Width_IPAD","Height_IPAD","Price_IPAD","Inch_Screen_IPAD","ID_Company_Tech", "Model_IPAD_Benefit")  
VALUES
(('IDBIP',1578964523),  2023-12-31, 'HUAWEI', 'Huawei', 240,160,130,10,('IDTHC',4425502300), 'MatePad T10');





INSERT INTO public."IPAD_BENEFIT"
("ID_Benefit_IPAD_Benefit","Assigned_Up_To_IPAD","OS_IPAD","Brand_IPAD","Width_IPAD","Height_IPAD","Price_IPAD","Inch_Screen_IPAD","ID_Company_Tech", "Model_IPAD_Benefit")  
VALUES
(('IDBIP',1234573560),  2024-12-31, 'Android', 'Lenovo', 163,258,279,11,('IDTHC',8420365197),'Lenovo Tab P11');





INSERT INTO public."IPAD_BENEFIT"
("ID_Benefit_IPAD_Benefit","Assigned_Up_To_IPAD","OS_IPAD","Brand_IPAD","Width_IPAD","Height_IPAD","Price_IPAD","Inch_Screen_IPAD","ID_Company_Tech", "Model_IPAD_Benefit")  
VALUES
(('IDBIP',3030332568),  2023-12-31, 'Android', 'Lenovo', 149,80,140,10,('IDTHC',8420365197),'Lenovo Tab M10 HD');



INSERT INTO public."IPAD_BENEFIT"
("ID_Benefit_IPAD_Benefit","Assigned_Up_To_IPAD","OS_IPAD","Brand_IPAD","Width_IPAD","Height_IPAD","Price_IPAD","Inch_Screen_IPAD","ID_Company_Tech", "Model_IPAD_Benefit")  
VALUES
(('IDBIP',3368452210),  2023-12-31, 'Android', 'Lenovo', 244, 153, 199, 10,('IDTHC',8420365197),'Lenovo Tab M10 FHD Plus');






