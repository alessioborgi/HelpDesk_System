
INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWAM',45200),'Account Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWAM',62501),'Account Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWAM',48502),'Account Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWAM',63203),'Account Manager' );


INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWAM',56204),'Account Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWAM',94505),'Account Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWAM',62306),'Account Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWAM',51207),'Account Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWAM',65208),'Account Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWAM',87500),'Account Manager' );


INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',58501),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',68602),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',52503),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',22404),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',23505),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',52606),'Business Manager' );




INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',98507),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',83808),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',59609),'Business Manager' );




INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',53610),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',35311),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',52512),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',82513),'Business Manager' );




INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',79514),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',85915),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',86816),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',26517),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',35218),'Business Manager' );



INSERT INTO public."MANAGER"
( "ID_Manager","Type_Manager")
VALUES
(('IDWBM',62419),'Business Manager' );



